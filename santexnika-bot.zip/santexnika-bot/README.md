# Santexnika Bot

Santexnika do'koni uchun mahsulot qoldig'i, sotuv va oddiy hisobotni yurituvchi Telegram bot.

## O'rnatish
`pip install -r requirements.txt`

`bot.py` ichidagi `BOT_TOKEN` qiymatiga Telegram BotFather tokenini kiriting.

## Buyruqlar
- `/start`
- `/mahsulotlar`
- `/qoshish kran 20 dona 85000`
- `/sotuv kran 2`
- `/hisobot`
